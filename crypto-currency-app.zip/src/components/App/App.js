import Currencies from '../Currencies/Currencies';
import './App.css';

function App() {
  
  return (
    <div className="App">
    <header className="App-header">
    <Currencies />
    </header>
    </div>
  );
}

export default App;
